// Archivo vehiculos.js
const vehiculosJSON = [
    {
        "propietario": "Carlos Gómez",
        "marca": "Toyota",
        "modelo": "Corolla",
        "placa": "XYZ-123",
        "anio": 2020,
        "observaciones": "Cambio de aceite reciente"
    },
    {
        "propietario": "Laura Fernández",
        "marca": "Honda",
        "modelo": "Civic",
        "placa": "ABC-789",
        "anio": 2018,
        "observaciones": "Frenos revisados"
    }
];
