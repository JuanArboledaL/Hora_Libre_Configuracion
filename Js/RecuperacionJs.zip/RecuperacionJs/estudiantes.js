let estudiantes = [
    {nombre:"Juan Esteban", edad: 21, curso:["Sistemas informaticos", "programacion", "lenguaje de marcas", "acceso a datos"], contacto:["juan@gmail.con",12344344], fechaRegistro: new Date("2024-03-11")},
    {nombre:"Marina", edad: 24, curso:["lenguaje de marcas", "acceso a datos"], contacto:["mar@gmail.con",12344344], fechaRegistro: new Date("2024-07-16")},
    {nombre:"Paquito", edad: 17, curso:["Sistemas informaticos"], contacto:["fdsf@gmail.con",7894561423], fechaRegistro: new Date("2024-09-02")},
    {nombre:"Pedro Nel", edad: 21, curso:["Sistemas informaticos", "acceso a datos"], contacto:["clas@gmail.con",785421369], fechaRegistro: new Date("2025-02-10")},
    {nombre:"Oscar", edad: 20, curso:["acceso a datos"], contacto:["asssn@gmail.con",87235689], fechaRegistro: new Date("2024-08-10")},
    {nombre:"Martin", edad: 22, curso:["programacion", "lenguaje de marcas", "acceso a datos"], contacto:["pals@gmail.con",8521569], fechaRegistro: new Date("2025-01-01")},
    {nombre:"Fernando", edad: 19, curso:["Sistemas informaticos", "programacion", "lenguaje de marcas", "acceso a datos"], contacto:["masrt@gmail.con",887546], fechaRegistro: new Date("2024-03-11")},
    {nombre:"Alberto", edad: 19, curso:["Sistemas informaticos", "programacion", "lenguaje de marcas", "acceso a datos"], contacto:["bichi@gmail.con",78598885], fechaRegistro: new Date("2024-03-11")},
];